Integrantes:
Hugo Catalan
Matias Carro
Ignacio Carné
Gabriel Carbajal

ORDEN DE LOS SCRIPTS:

01_esquema - Crea las tablas

02 catalogo - Crea el catalogo con los valores

03_carga_masiva - Carga masiva de datos

04_indices - Creación de índices

05_consultas_y_explain - Consultas de la base de datos y los explain

06_seguridad_vistas_seguras - Seguridad, creación de usuario con bajos permisos y de las vistas seguras

07_transacciones - Procedimiento de transacción almacenado en SQL

08_Concurrencia_guiada - Pruebas de deadlocks, seguir los pasos y utilizar 08_Concurrencia_guiada_sesion2 para las pruebas